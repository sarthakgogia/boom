<div class="animate-out">
	<div class="console-wrapper">	
		<div class="console-loader-wrapper">
			<span class="lnr lnr-cog fa-spin"></span>
		</div>
		<div class="con-r1-gen">
			<div class="con-r1-gen-inner">
				<img class="resource-img" src="img/input-icon.png" alt="CashApp Icon" />
				<div class="con-r1-gen-val">0</div>
			</div>
		</div>
		<div class="console-msg-wrapper animated fadeInUp animation-delay-800">	
			<div class="console-msg"></div>			
		</div>
	</div>
</div>