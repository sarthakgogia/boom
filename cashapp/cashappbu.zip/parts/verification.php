<div class="human-verification-main animated flipInX">
	<h3>Human Verification Required</h3>	
	<p>You are almost done! Please VERIFY that you are human and not a software (automated bot).<br> After successfully verified, the  <b>$CASH</b> will be added to your Cash App account.</p>
	<i class="fa fa-spinner fa-spin"></i>
	<div id="h-v-time-left-wrapper" class="h-v-time-left-wrapper">
		<span>Time Left:</span>
		<span id="human_verification_timer_time"></span>
	</div>
	<div class="verification-button-wrapper">
		<a id="verification-button" class="button" onclick="LetsMakeMoney();">Verify Now</a>
	</div>
</div>